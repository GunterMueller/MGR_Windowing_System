/*                        Copyright (c) 1988 Bellcore
 *                            All Rights Reserved
 *       Permission is granted to copy or use this program, EXCEPT that it
 *       may not be sold for profit, the copyright notice must be reproduced
 *       on copies, and credit should be given to Bellcore where it is due.
 *       BELLCORE MAKES NO WARRANTY AND ACCEPTS NO LIABILITY FOR THIS PROGRAM.
 */
/*	$Header: pixel.c,v 4.1 88/06/21 13:08:06 bianchi Exp $
	$Source: /tmp/mgrsrc/src/oblit/RCS/pixel.c,v $
*/
static char	RCSid_[] = "$Source: /tmp/mgrsrc/src/oblit/RCS/pixel.c,v $$Revision: 4.1 $";

/* draw a point  stub */

#include "bitmap.h"

int
bit_point(map, dx, dy, func)
BITMAP *map;
register int dx, dy;
int func;
   {
   }
