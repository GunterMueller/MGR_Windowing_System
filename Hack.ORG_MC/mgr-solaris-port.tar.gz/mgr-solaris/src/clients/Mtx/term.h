#define OLDMGRBITOPS
#include <mgr/mgr.h>
