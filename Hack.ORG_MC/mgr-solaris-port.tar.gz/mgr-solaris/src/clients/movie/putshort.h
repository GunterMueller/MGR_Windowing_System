#define putshort(n) fputshort(n,stdin)

short int fputshort(short int n, FILE *fp);
