double getload(void);
