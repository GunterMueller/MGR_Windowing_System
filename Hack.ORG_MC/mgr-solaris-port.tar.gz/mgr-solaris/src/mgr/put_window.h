void set_size(WINDOW *win);
int put_window(WINDOW *win, unsigned char *buff, int buff_count);
/*{{{}}}*/
