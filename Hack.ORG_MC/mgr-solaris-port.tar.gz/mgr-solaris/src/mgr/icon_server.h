/* bitmaps used by mgr server, file is created by make(1) */
extern BITMAP ball_1;
extern BITMAP ball_2;
extern BITMAP ball_3;
extern BITMAP ball_4;
extern BITMAP ball_5;
extern BITMAP ball_6;
extern BITMAP ball_7;
extern BITMAP ball_8;
extern BITMAP cr;
extern BITMAP def_pattern;
extern BITMAP mouse_arrow;
extern BITMAP mouse_box;
extern BITMAP mouse_bull;
extern BITMAP mouse_bull2;
extern BITMAP mouse_cross;
extern BITMAP mouse_cup;
extern BITMAP mouse_cut;
