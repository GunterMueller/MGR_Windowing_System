int write_ok(char *name);
int read_ok(char *name);
int mode_ok(char *name,int mask);
/*{{{}}}*/
