void scroll(WINDOW *win, BITMAP *map, int start, int end, int delta, int op);
