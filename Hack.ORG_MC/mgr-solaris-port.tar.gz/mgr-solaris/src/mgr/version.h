/* compilation info for mgr, file is created by make(1) */

char version[]="MGR version 0.69 compiled by mc at Fri Sep  6 18:40:33 MET DST 1996.
System: SunOS tingeling 5.4 Generic_101945-42 sun4 sparc
";
