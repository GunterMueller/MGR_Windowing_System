int Write(int fd, char *buff, int len);
