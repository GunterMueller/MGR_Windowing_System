void win_rop(WINDOW *win, BITMAP *window);
void win_map(WINDOW *win, BITMAP *window);
void win_plot(WINDOW *win, BITMAP *window);
void Bit_line(WINDOW *win, BITMAP *dst,int x1,int y1,int x2,int y2,int op);
void grunch(WINDOW *win, BITMAP *dst);
void circle_plot(WINDOW *win,BITMAP *window);
void win_go(WINDOW *win);
int bmap_size(int w,int h,int count);
/*{{{}}}*/
