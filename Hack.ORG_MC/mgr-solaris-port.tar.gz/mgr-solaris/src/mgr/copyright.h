void copyright(BITMAP *where, char *password);
