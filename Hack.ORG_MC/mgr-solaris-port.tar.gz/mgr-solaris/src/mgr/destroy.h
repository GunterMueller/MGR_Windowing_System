void unlink_win(WINDOW *win, int how);
int destroy(WINDOW *win);
void destroy_window(void);
