void startup(char *name);
void do_cmd(char flag);
void initwindow(void);
