void initbell(void);
void bell_on(void);
void kbd_reset(void);
int set_kbd(int how);
void initkbd(void);
/*{{{}}}*/
