int mouse_get(int mouse, int *x_delta, int *y_delta);
int *map_mouse(int button, int map);
int mouse_count(void);
/*{{{}}}*/
