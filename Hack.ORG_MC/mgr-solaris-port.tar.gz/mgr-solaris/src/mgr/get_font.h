struct font *get_font(char *name);
struct font *Get_font(int fnt);
/*{{{}}}*/
