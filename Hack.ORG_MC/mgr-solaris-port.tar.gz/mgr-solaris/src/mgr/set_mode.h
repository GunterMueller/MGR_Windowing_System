void set_tty(int file);
void reset_tty(int file);
void save_modes(int fd);
void restore_modes(int fd);
void adjust_mode(int disc, int flags);
/*{{{}}}*/
