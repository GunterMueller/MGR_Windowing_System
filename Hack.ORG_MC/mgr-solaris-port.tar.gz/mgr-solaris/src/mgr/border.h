void border(WINDOW *win, int be_fat);
