void erase_win(BITMAP *map);
