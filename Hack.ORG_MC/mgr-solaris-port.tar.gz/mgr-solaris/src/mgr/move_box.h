void move_box(BITMAP *screen,int mouse,int *x,int *y,int dx,int dy,int how);
/*{{{}}}*/
