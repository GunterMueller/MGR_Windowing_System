void get_info(WINDOW *win,BITMAP *window,BITMAP *text);
/*{{{}}}*/
