void move_window(void);
/*{{{}}}*/
