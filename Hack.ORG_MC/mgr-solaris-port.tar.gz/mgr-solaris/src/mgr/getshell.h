char *last_tty(void);
int get_command(char **argv, int *file);
char *half_open(int *file);
