extern BITMAP *pattern;
extern char *log_command;
extern FILE *log_file;

extern int mouse_reopen(void);
extern int get_bm_type(void);
/*{{{}}}*/
