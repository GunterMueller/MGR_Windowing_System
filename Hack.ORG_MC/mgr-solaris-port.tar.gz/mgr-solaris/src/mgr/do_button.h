extern void _quit(void);
extern void redraw(void);
extern void quit(void);
extern void do_button(int button);
extern void hide_win(void);
/*{{{}}}*/
