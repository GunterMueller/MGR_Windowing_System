void down_load(WINDOW *win, BITMAP *window, BITMAP *text);
/*{{{}}}*/
