void paste(void);
int cut(int mode);
void rubber_band_cut(void);
void zap_fhash(struct font *fnt);
/*{{{}}}*/
