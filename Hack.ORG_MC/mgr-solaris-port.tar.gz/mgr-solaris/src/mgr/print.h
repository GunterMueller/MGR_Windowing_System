#ifdef DEBUG
extern char *print_flags(int n);
extern char *print_menu(int n);
extern char *print_stack(int n);
extern char *print_events(int n);
extern int get_ps(void);
extern void free_ps(void);
extern char *print_ps(char *tty);
#endif
