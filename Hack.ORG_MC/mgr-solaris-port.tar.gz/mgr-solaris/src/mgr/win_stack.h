int win_push(WINDOW *win,int level);
int win_pop(WINDOW *win);
