int do_buckey(unsigned char c);
void topwin(int winsetid, int winnum);
