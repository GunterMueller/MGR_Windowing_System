void win_make(WINDOW *win, int indx);
