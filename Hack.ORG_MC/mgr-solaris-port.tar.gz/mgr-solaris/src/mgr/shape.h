void shape_window(void);
#ifdef STRETCH
void stretch_window(void);
#endif
int shape(int x, int y, int dx, int dy);
