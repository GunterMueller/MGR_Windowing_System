void rm_utmp(char *line);
void add_utmp(char *line);
/*{{{}}}*/
