void write_event(WINDOW *win, char *str, char *list);
void do_event(int event, WINDOW *win, int flag);
/*{{{}}}*/
