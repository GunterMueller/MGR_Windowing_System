void zap_cliplist(WINDOW *win);
void update(WINDOW *win, rect *clipp);
void clip_bad(WINDOW *window);
