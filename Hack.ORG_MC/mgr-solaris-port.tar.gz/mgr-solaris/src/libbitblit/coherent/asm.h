/*
/* asm.h -- definitions for preprocessing .S assembler files
/*

BPW	.define	4			/* bytes per word */
LBPW	.define	2
