void _cld(/* void */);
void _std(/* void */);
void _do_mask(/* char *dst, int mask, int func */);
