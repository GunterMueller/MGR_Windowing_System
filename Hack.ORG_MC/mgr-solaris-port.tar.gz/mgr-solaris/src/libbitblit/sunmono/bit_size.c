#include "screen.h"

int bit_size(int wide, int high, unsigned char depth)
{
  return BIT_Size(wide,high,depth);
}
